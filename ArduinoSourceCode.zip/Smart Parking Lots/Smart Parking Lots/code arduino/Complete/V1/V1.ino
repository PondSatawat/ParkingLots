/*
 * ========================================================
 * ===    โค้ดรวม (Servo + LCD + Buzzer + IR Guard)      ===
 * ========================================================
 */

/* Comment this out to disable prints and save space */
#define BLYNK_PRINT Serial
#define BLYNK_TEMPLATE_ID "TMPL6o6yhl5E2"
#define BLYNK_TEMPLATE_NAME "SERVO"
#define BLYNK_AUTH_TOKEN "MktnzUmPaI7GUyUH9GEcirfNF3cNT_Q-"

// --- (1) รวม #include ---
#include <WiFi.h>
#include <WiFiClient.h>
#include <BlynkSimpleEsp32.h>
#include <ESP32Servo.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// --- (2) รวมตัวแปร Global ---
Servo servo1, servo2;
char auth[] = BLYNK_AUTH_TOKEN;
char ssid[] = "numtb5332";
char pass[] = "num53322535";
LiquidCrystal_I2C lcd(0x27, 16, 2);
#define SDA_PIN 21
#define SCL_PIN 22
const int totalSpots = 2;
int irPins[totalSpots] = { 32, 35 }; // IR 1 (Spot 1) = Pin 32, IR 2 (Spot 2) = Pin 35
int lastStatus[totalSpots];
int occupiedSpots = 0;
int availableSpots = 0;
const int buzzerPin = 19;
const int buzzerFreq = 2500;
const int resolution = 8;
const int VOLUME_OFF = 0;
const int BEEP_VOLUME = 128;
const int BEEP_DURATION = 50; 
BlynkTimer timer;

// --- (3) ฟังก์ชันจาก servo.ino (แก้ไข) ---
BLYNK_WRITE(V0)
{
  int s0 = param.asInt(); 
  int sensorState1 = digitalRead(irPins[0]); 
  
  if (sensorState1 == LOW) {
    Serial.println("Spot 1: Car detected. Moving Servo 1.");
    servo1.write(s0);
    Blynk.virtualWrite(V2, s0);
    doBeep(); 
  } else {
    Serial.println("Spot 1: NO car detected. Servo 1 NOT moving.");
    // --- (แก้ไข) เปลี่ยน notify เป็น logEvent ---
    Blynk.logEvent("no_car", "Cannot move Servo 1: No car detected!");
  }
} 

BLYNK_WRITE(V1)
{
  int s1 = param.asInt(); 
  int sensorState2 = digitalRead(irPins[1]); 

  if (sensorState2 == LOW) {
    Serial.println("Spot 2: Car detected. Moving Servo 2.");
    servo2.write(s1);
    Blynk.virtualWrite(V3, s1);
    doBeep(); 
  } else {
    Serial.println("Spot 2: NO car detected. Servo 2 NOT moving.");
    // --- (แก้ไข) เปลี่ยน notify เป็น logEvent ---
    Blynk.logEvent("no_car", "Cannot move Servo 2: No car detected!");
  }
} 

// --- (4) ฟังก์ชันจาก parking.ino ---
void updateLCD() {
  availableSpots = totalSpots - occupiedSpots;
  lcd.clear();
  lcd.setCursor(0, 0); 
  lcd.print("Occupied: ");
  lcd.print(occupiedSpots);
  lcd.print(" / ");
  lcd.print(totalSpots);
  lcd.setCursor(0, 1);
  lcd.print("Available: ");
  lcd.print(availableSpots);
}

// --- (5) ฟังก์ชันสำหรับเปิด/ปิดเสียงติ๊ด ---
void stopBeep() {
  ledcWrite(buzzerPin, VOLUME_OFF); // ปิดเสียง
}

void doBeep() {
  Serial.println("Servo moved! (Beep!)");
  ledcWrite(buzzerPin, BEEP_VOLUME); // 1. เปิดเสียง
  timer.setTimeout(BEEP_DURATION, stopBeep); // 2. ตั้งเวลาปิดเสียง (non-blocking)
}

// --- (6) ฟังก์ชันเช็คที่จอดรถ ---
void checkParkingSensors()
{ 
  bool statusHasChanged = false;
  
  for (int i = 0; i < totalSpots; i++) { 
    int currentState = 0;
    int sensorState = digitalRead(irPins[i]);

    if (sensorState == LOW) { 
      currentState = 1;
    } 

    if (currentState != lastStatus[i]) { 
      if (currentState == 1) { 
        occupiedSpots++;
        Serial.print("Spot "); Serial.print(i); Serial.println(" -> PARKED");
      } else { 
        occupiedSpots--;
        Serial.print("Spot "); Serial.print(i);
        Serial.println(" -> EMPTY");
      } 
      lastStatus[i] = currentState;
      statusHasChanged = true;
    } 
  } 

  if (statusHasChanged) { 
    Serial.println("Change detected, updating LCD...");
    updateLCD();
  } 
} 

//==================================================
// SETUP: 
//==================================================
void setup()
{
  Serial.begin(115200);

  servo1.attach(26);
  servo2.attach(27);
  
  Wire.begin(SDA_PIN, SCL_PIN);
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Parking System");
  lcd.setCursor(0, 1);
  lcd.print("Scanning...");

  ledcAttach(buzzerPin, buzzerFreq, resolution);
  ledcWrite(buzzerPin, VOLUME_OFF); 
  
  for (int i = 0; i < totalSpots; i++) {
    pinMode(irPins[i], INPUT); 
    int sensorState = digitalRead(irPins[i]);
    if (sensorState == LOW) {
      lastStatus[i] = 1;
      occupiedSpots++;
    } else {
      lastStatus[i] = 0;
    }
  }
  
  Serial.println("Initial scan complete.");
  updateLCD();

  Blynk.begin(auth , ssid, pass);
  
  timer.setInterval(100L, checkParkingSensors);
}

//==================================================
// LOOP:
//==================================================
void loop() 
{
  Blynk.run();
  timer.run();
}