/*
 * ========================================================
 * ===    โค้ดรวม (Blynk + Firebase RTDB + LCD + 8 IR)   ===
 * ========================================================
 */

// --- (1) Library ---
#include <WiFi.h>
#include <WiFiClient.h>
#include <ESP32Servo.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <Firebase_ESP_Client.h> 

// (ย้าย) #define ของ Blynk ขึ้นมาก่อน
#define BLYNK_PRINT Serial
#define BLYNK_TEMPLATE_ID "TMPL6o6yhl5E2"
#define BLYNK_TEMPLATE_NAME "SERVO"
#define BLYNK_AUTH_TOKEN "MktnzUmPaI7GUyUH9GEcirfNF3cNT_Q-"
#include <BlynkSimpleEsp32.h> 

// --- (2) Configs ---
//char ssid[] = "numtb5332";
//char pass[] = "num53322535";
char ssid[] = "Sakchai_2.4G";
char pass[] = "3112311231";

// --- (3) Global Variables ---
Servo servo1, servo2;
LiquidCrystal_I2C lcd(0x27, 16, 2);
#define SDA_PIN 21
#define SCL_PIN 22

// (แก้ไข) เพิ่มเป็น 8 ช่อง
const int totalSpots = 8;
int irPins[totalSpots] = { 32, 35};
int lastStatus[totalSpots];
int occupiedSpots = 0;
int availableSpots = 0;

// (เพิ่ม) เติมตัวแปร Buzzer ที่หายไป
const int buzzerPin = 19;
const int buzzerFreq = 2500;
const int resolution = 8;
const int VOLUME_OFF = 0;
const int BEEP_VOLUME = 128;
const int BEEP_DURATION = 50;
BlynkTimer timer;

char auth[] = BLYNK_AUTH_TOKEN;

// (Firebase Objects)
FirebaseData fbdo;
FirebaseAuth auth_firebase;
FirebaseConfig config_firebase;

// --- (4) ฟังก์ชัน Blynk และ Hardware (เติมส่วนที่ขาด) ---
BLYNK_WRITE(V0) { 
  int s0 = param.asInt();
  Serial.println("Servo 1 moving (command from web/app).");
  servo1.write(s0);
  Blynk.virtualWrite(V2, s0);
  doBeep();
}
BLYNK_WRITE(V1) { 
  int s1 = param.asInt();
  Serial.println("Servo 2 moving (command from web/app).");
  servo2.write(s1);
  Blynk.virtualWrite(V3, s1);
  doBeep();
}
void updateLCD() { 
  availableSpots = totalSpots - occupiedSpots;
  lcd.clear();
  lcd.setCursor(0, 0); 
  lcd.print("Occupied: ");
  lcd.print(occupiedSpots);
  lcd.print(" / ");
  lcd.print(totalSpots);
  lcd.setCursor(0, 1);
  lcd.print("Available: ");
  lcd.print(availableSpots);
}
void stopBeep() { 
  ledcWrite(buzzerPin, VOLUME_OFF);
}
void doBeep() { 
  Serial.println("Servo moved! (Beep!)");
  ledcWrite(buzzerPin, BEEP_VOLUME);
  timer.setTimeout(BEEP_DURATION, stopBeep);
}

// --- (5) (แก้ไข) ฟังก์ชันเช็คที่จอดรถ ---
void checkParkingSensors()
{ 
  bool statusHasChanged_LCD = false; // (ธงสำหรับ LCD)

  // (Loop นี้จะวน 8 รอบ)
  for (int i = 0; i < totalSpots; i++) {
    int currentState = 0;
    int sensorState = digitalRead(irPins[i]);

    if (sensorState == LOW) {
      currentState = 1; // 1 = จอด
    } 

    // (โค้ดสำหรับนับที่จอด (occupiedSpots) และอัปเดต LCD)
    if (currentState != lastStatus[i]) {
      if (currentState == 1) { 
          occupiedSpots++;
          Serial.print("Spot "); Serial.print(i); Serial.println(" -> PARKED");
      } else { 
          occupiedSpots--;
          Serial.print("Spot "); Serial.print(i); Serial.println(" -> EMPTY");
      } 
      
      //
      // 👇 (แก้ไข Logic การตั้งชื่อ Spot) 👇
      //
      String spotName = "";
      if (i < 4) {
        // (i = 0 ถึง 3) -> แถว A
        spotName = "A" + String(i + 1); // A1, A2, A3, A4
      } else {
        // (i = 4 ถึง 7) -> แถว B
        spotName = "B" + String(i - 3); // (i-4+1) -> B1, B2, B3, B4
      }
      
      // (ส่งสถานะไป Firebase RTDB)
      if(Firebase.RTDB.setInt(&fbdo, "/parkingStatus/spots/" + spotName, currentState)) {
         Serial.print("RTDB "); Serial.print(spotName); Serial.print(" status sent: ");
         Serial.println(currentState);
      } else {
         Serial.println("RTDB FAILED: " + fbdo.errorReason());
      }
      //
      // 👆 (สิ้นสุดส่วนที่แก้ไข) 👆
      //
      
      lastStatus[i] = currentState;
      statusHasChanged_LCD = true;
    } 
  
  } // 👈 (FIX 1) (เพิ่ม '}' ที่ขาดไปของ 'for' loop)

  if (statusHasChanged_LCD) {
    Serial.println("Change detected, updating LCD...");
    updateLCD();
  } 
} // <-- (นี่คือ '}' ที่จบฟังก์ชัน checkParkingSensors)

//==================================================
// SETUP: (แก้ไข)
//==================================================
void setup()
{
  Serial.begin(115200);

  // --- (1) Setup Hardware (เติมส่วนที่ขาด) ---
  servo1.attach(26);
  servo2.attach(27);
  Wire.begin(SDA_PIN, SCL_PIN);
  lcd.init();
  lcd.backlight();
  
  // (เพิ่ม) เติมโค้ด Buzzer ที่หายไป
  ledcAttach(buzzerPin, buzzerFreq, resolution);
  ledcWrite(buzzerPin, VOLUME_OFF); 
  
  // (Loop นี้จะวน 8 รอบ)
  for (int i = 0; i < totalSpots; i++) {
    pinMode(irPins[i], INPUT);
    
    // (เพิ่ม) เติมโค้ดสแกนครั้งแรกที่หายไป
    int sensorState = digitalRead(irPins[i]);
    if (sensorState == LOW) {
      lastStatus[i] = 1;
      occupiedSpots++;
    } else {
      lastStatus[i] = 0;
    }
  }
  updateLCD();

  // --- (2) [ใหม่] เชื่อมต่อ WiFi ก่อน ---
  Serial.print("Connecting to Wi-Fi...");
  WiFi.begin(ssid, pass);
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(500);
  }
  Serial.println(" Connected!");

  // --- (3) [ใหม่] เชื่อมต่อ Firebase ---
  config_firebase.api_key = "AIzaSyCgKTtjGEHyoqZ0cDa5QZMwQe8c0iSEo4w";
  config_firebase.database_url = "https://loginparklotconsole-default-rtdb.asia-southeast1.firebasedatabase.app";
  auth_firebase.user.email = "esp32@project.com";
  auth_firebase.user.password = "esp32pass";
  Firebase.begin(&config_firebase, &auth_firebase);
  Firebase.reconnectWiFi(true);
  
  // (เพิ่ม) เติมโค้ดส่งสถานะเริ่มต้น
  Serial.println("Sending initial status to RTDB...");
  for (int i = 0; i < totalSpots; i++) {
    // (ใช้ Logic การตั้งชื่อเดียวกับ checkParkingSensors)
    String spotName = "";
    if (i < 4) {
      spotName = "A" + String(i + 1);
    } else {
      spotName = "B" + String(i - 3);
    }
    Firebase.RTDB.setInt(&fbdo, "/parkingStatus/spots/" + spotName, lastStatus[i]);
  }

  // --- (4) [ใหม่] เชื่อมต่อ Blynk (โดยใช้ WiFi ที่ต่อแล้ว) ---
  Blynk.config(auth);
  Blynk.connect();

  // --- (5) ตั้ง Timer (เหมือนเดิม) ---
  timer.setInterval(100L, checkParkingSensors);
}

//
// 🚀 (FIX 2) เพิ่ม 'void loop()' ที่หายไป
//
void loop() 
{
  Blynk.run(); // (ต้องมี)
  timer.run(); // (ต้องมี)
}