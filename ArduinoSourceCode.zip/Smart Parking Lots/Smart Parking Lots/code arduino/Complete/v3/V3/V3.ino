/*
 * ========================================================
 * ===    โค้ดรวม (Servo + LCD + Buzzer + IR Guard)      ===
 * ========================================================
 */

/* Comment this out to disable prints and save space */
#define BLYNK_PRINT Serial
#define BLYNK_TEMPLATE_ID "TMPL6o6yhl5E2"
#define BLYNK_TEMPLATE_NAME "SERVO"
#define BLYNK_AUTH_TOKEN "MktnzUmPaI7GUyUH9GEcirfNF3cNT_Q-"

// --- (1) รวม #include ---
#include <WiFi.h>
#include <WiFiClient.h>
// (ย้าย) #define ของ Blynk ขึ้นมาก่อน
#define BLYNK_PRINT Serial
#define BLYNK_TEMPLATE_ID "TMPL6o6yhl5E2"
#define BLYNK_TEMPLATE_NAME "SERVO"
#define BLYNK_AUTH_TOKEN "MktnzUmPaI7GUyUH9GEcirfNF3cNT_Q-"
#include <BlynkSimpleEsp32.h> // 👈 (ย้าย include มาไว้หลัง #define)
#include <ESP32Servo.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// --- (2) รวมตัวแปร Global ---
Servo servo1, servo2;
char auth[] = BLYNK_AUTH_TOKEN;
char ssid[] = "numtb5332";
char pass[] = "num53322535";
LiquidCrystal_I2C lcd(0x27, 16, 2);
#define SDA_PIN 21
#define SCL_PIN 22
const int totalSpots = 2;
int irPins[totalSpots] = { 32, 35 };
int lastStatus[totalSpots];
int occupiedSpots = 0;
int availableSpots = 0;
const int buzzerPin = 19;
const int buzzerFreq = 2500;
const int resolution = 8;
const int VOLUME_OFF = 0;
const int BEEP_VOLUME = 128;
const int BEEP_DURATION = 50;
BlynkTimer timer;

// (เพิ่ม) ตัวแปรสำหรับจำสถานะ Sensor ทางเข้า (V3)
int lastEntranceStatus = -1;

// --- (3) (แก้ไข) ฟังก์ชัน Servo 1 (ทางเข้า) ---
// (ลบ if check sensor ออก, ให้ทำงานทันทีที่ V0 ถูกสั่ง)
BLYNK_WRITE(V0)
{
  int s0 = param.asInt();
  Serial.println("Servo 1 moving (command from web/app).");
  servo1.write(s0);
  Blynk.virtualWrite(V2, s0);
  doBeep();
}

// --- (แก้ไข) ฟังก์ชัน Servo 2 (ทางออก) ---
// (ลบ if check sensor ออก, ให้ทำงานทันทีที่ V1 ถูกสั่ง)
BLYNK_WRITE(V1)
{
  int s1 = param.asInt();
  Serial.println("Servo 2 moving (command from web/app).");
  servo2.write(s1);
  Blynk.virtualWrite(V3, s1);
  doBeep();
}

// --- (4) ฟังก์ชัน LCD (เหมือนเดิม) ---
void updateLCD() {
  availableSpots = totalSpots - occupiedSpots;
  lcd.clear();
  lcd.setCursor(0, 0); 
  lcd.print("Occupied: ");
  lcd.print(occupiedSpots);
  lcd.print(" / ");
  lcd.print(totalSpots);
  lcd.setCursor(0, 1);
  lcd.print("Available: ");
  lcd.print(availableSpots);
}

// --- (5) ฟังก์ชันเสียง Beep (เหมือนเดิม) ---
void stopBeep() {
  ledcWrite(buzzerPin, VOLUME_OFF);
}

void doBeep() {
  Serial.println("Servo moved! (Beep!)");
  ledcWrite(buzzerPin, BEEP_VOLUME);
  timer.setTimeout(BEEP_DURATION, stopBeep);
}

// --- (6) (แก้ไข) ฟังก์ชันเช็คที่จอดรถ ---
void checkParkingSensors()
{ 
  bool statusHasChanged = false;

  for (int i = 0; i < totalSpots; i++) {
    int currentState = 0;
    int sensorState = digitalRead(irPins[i]);

    if (sensorState == LOW) {
      currentState = 1;
    } 

    //
    // 👇 (Logic นี้ถูกต้องแล้ว - จากไฟล์ V2.ino) 👇
    //
    // ถ้าเป็น Sensor ตัวที่ 0 (ทางเข้า) และสถานะเพิ่งเปลี่ยน
    if (i == 0 && currentState != lastEntranceStatus) {
      // ส่งสถานะนี้ไปที่ V3
      Blynk.virtualWrite(V3, currentState);
      Serial.print("Entrance Sensor (V3) status sent: ");
      Serial.println(currentState);
      lastEntranceStatus = currentState;
    }
    //
    // 👆 (สิ้นสุดส่วนที่เพิ่ม) 👆
    //

    // (โค้ดสำหรับนับที่จอด (occupiedSpots) เหมือนเดิม)
    if (currentState != lastStatus[i]) {
      if (currentState == 1) { 
        occupiedSpots++;
        Serial.print("Spot "); Serial.print(i); Serial.println(" -> PARKED");
      } else { 
        occupiedSpots--;
        Serial.print("Spot ");
        Serial.print(i);
        Serial.println(" -> EMPTY");
      } 
      lastStatus[i] = currentState;
      statusHasChanged = true;
    } 
  } 

  if (statusHasChanged) {
    Serial.println("Change detected, updating LCD...");
    updateLCD();
  } 
} 

//==================================================
// SETUP: (เหมือนเดิม)
//==================================================
void setup()
{
  Serial.begin(115200);

  servo1.attach(26);
  servo2.attach(27);
  
  Wire.begin(SDA_PIN, SCL_PIN);
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Parking System");
  lcd.setCursor(0, 1);
  lcd.print("Scanning...");

  ledcAttach(buzzerPin, buzzerFreq, resolution);
  ledcWrite(buzzerPin, VOLUME_OFF);
  
  for (int i = 0; i < totalSpots; i++) {
    pinMode(irPins[i], INPUT);
    int sensorState = digitalRead(irPins[i]);
    if (sensorState == LOW) {
      lastStatus[i] = 1;
      occupiedSpots++;
    } else {
      lastStatus[i] = 0;
    }
  }
  
  Serial.println("Initial scan complete.");
  updateLCD();

  Blynk.begin(auth , ssid, pass);
  
  timer.setInterval(100L, checkParkingSensors);
}

//==================================================
// LOOP: (เหมือนเดิม)
//==================================================
void loop() 
{
  Blynk.run();
  timer.run();
}