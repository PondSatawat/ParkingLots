#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// --- (1) ตั้งค่าจอ LCD ---
LiquidCrystal_I2C lcd(0x27, 16, 2); // (หรือ 0x3F ถ้า 0x27 ใช้ไม่ได้)
#define SDA_PIN 21
#define SCL_PIN 22

// --- (2) ตั้งค่า IR Sensor ---
const int totalSpots = 8; // จำนวนที่จอดทั้งหมด

// *** (แก้เลข Pin ในนี้ให้ตรงกับที่คุณต่อจริง) ***
int irPins[totalSpots] = { 32,35 };

// --- (3) ตรรกะ "จำสถานะล่าสุด" (จากโค้ดที่ 2) ---
// เราจะใช้ int (0 = ว่าง, 1 = จอด) เพื่อประหยัด Memory แทน String
int lastStatus[totalSpots]; 

// --- (4) ตัวแปรสำหรับนับ ---
int occupiedSpots = 0;  // ตัวนับรถที่จอดอยู่
int availableSpots = 0; // ที่ว่าง (จะถูกคำนวณ)

//==================================================
// SETUP: ทำงานครั้งเดียวตอนเปิดเครื่อง
//==================================================
void setup() {
  Serial.begin(115200); // (สำหรับ Debug)
  
  // เริ่มต้น I2C (ต้องระบุ Pin สำหรับ ESP32)
  Wire.begin(SDA_PIN, SCL_PIN); 

  // เริ่มต้นจอ LCD
  lcd.init();
  lcd.backlight(); // เปิดไฟหน้าจอ
  lcd.setCursor(0, 0);
  lcd.print("Parking System");
  lcd.setCursor(0, 1);
  lcd.print("Scanning...");

  // --- (สำคัญ) สแกนครั้งแรกเพื่อหาค่าเริ่มต้น ---
  for (int i = 0; i < totalSpots; i++) {
    pinMode(irPins[i], INPUT);
    
    // อ่านค่า Sensor
    int sensorState = digitalRead(irPins[i]);
    
    if (sensorState == LOW) { // LOW = มีรถจอด
      lastStatus[i] = 1; // 1 = จอด
      occupiedSpots++;   // นับเพิ่ม
    } else {
      lastStatus[i] = 0; // 0 = ว่าง
    }
  }

  Serial.println("Initial scan complete.");
  Serial.print("Initial Occupied: "); Serial.println(occupiedSpots);

  // อัปเดตจอ LCD ด้วยค่าเริ่มต้น
  updateLCD();
}

//==================================================
// LOOP: ทำงานวนซ้ำตลอดเวลา
//==================================================
void loop() {
  
  bool statusHasChanged = false; // "ธง" สำหรับบอกว่าต้องอัปเดตจอหรือไม่

  // --- (A) วนลูปเช็ก Sensor ทั้ง 8 ตัว ---
  for (int i = 0; i < totalSpots; i++) {
    
    int currentState = 0; // 0 = ว่าง (สมมติว่าว่างไว้ก่อน)
    int sensorState = digitalRead(irPins[i]);

    if (sensorState == LOW) { // LOW = มีรถ
      currentState = 1; // 1 = จอด
    }

    // --- (B) นี่คือตรรกะจากโค้ดที่ 2: ตรวจสอบว่าสถานะเปลี่ยนหรือไม่ ---
    if (currentState != lastStatus[i]) {
      
      // สถานะเพิ่งเปลี่ยน!
      if (currentState == 1) {
        // รถเพิ่งเข้าจอด (จาก 0 -> 1)
        occupiedSpots++;
        Serial.print("Spot "); Serial.print(i); Serial.println(" -> PARKED");
      } else {
        // รถเพิ่งออกไป (จาก 1 -> 0)
        occupiedSpots--;
        Serial.print("Spot "); Serial.print(i); Serial.println(" -> EMPTY");
      }

      lastStatus[i] = currentState; // อัปเดตค่าที่จำไว้
      statusHasChanged = true;      // ตั้ง "ธง" ว่าต้องอัปเดตจอ
    }
  } // สิ้นสุด For Loop

  // --- (C) อัปเดตจอ (เฉพาะเมื่อมีอะไรเปลี่ยนแปลง) ---
  if (statusHasChanged) {
    Serial.println("Change detected, updating LCD...");
    updateLCD(); // เรียกฟังก์ชันอัปเดตจอ
  }

  // หน่วงเวลาเล็กน้อยก่อนสแกนรอบถัดไป
  delay(100); // สแกนทุก 0.1 วินาที (เร็ว แต่มีประสิทธิภาพ)
}

//==================================================
// ฟังก์ชันสำหรับอัปเดตจอ LCD
// (แยกออกมาให้โค้ดสะอาด)
//==================================================
void updateLCD() {
  // คำนวณที่ว่าง
  availableSpots = totalSpots - occupiedSpots;

  // บรรทัดบน (แสดง "จอดอยู่")
  lcd.clear(); // ล้างจอก่อนเขียนใหม่
  lcd.setCursor(0, 0); 
  lcd.print("Occupied: ");
  lcd.print(occupiedSpots);
  lcd.print(" / ");
  lcd.print(totalSpots);

  // บรรทัดล่าง (แสดง "ว่าง")
  lcd.setCursor(0, 1);
  lcd.print("Available: ");
  lcd.print(availableSpots);
}