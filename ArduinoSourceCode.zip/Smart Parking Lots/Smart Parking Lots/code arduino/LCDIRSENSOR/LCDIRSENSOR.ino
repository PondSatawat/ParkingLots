/*
 * ========================================================
 * ===    โค้ดรวม (8 IR + 2 Servo + LCD + Buzzer + Blynk) ===
 * ========================================================
 *
 * ไฟล์นี้รวมการทำงานจาก:
 * 1. V2.ino (2 Servo, LCD, Buzzer)
 * 2. IRSensorBlynkv2.ino (8-sensor logic, V10-V17)
 *
 * ผลลัพธ์:
 * - ควบคุม Servo 2 ตัวผ่าน V0, V1
 * - ส่งเสียง Buzzer เมื่อ Servo ทำงาน
 * - อ่านค่า IR Sensor 8 ตัว
 * - ส่งสถานะ Sensor ทั้ง 8 ตัว (i=0 ถึง 7) ไปที่ V10-V17
 * - นับจำนวนที่จอดที่ "เต็ม" (occupied) จาก 8 ตัว
 * - แสดงผล "Occupied" และ "Available" (จาก 8) บน LCD
 */

// --- (1) รวม Libraries จากทั้ง 2 ไฟล์ ---
#include <WiFi.h>
#include <WiFiClient.h>
#include <ESP32Servo.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// --- (2) Configs Wi-Fi / Blynk (ใช้จาก V2.ino) ---
/* * !!! สำคัญ !!!
 * คุณต้องไปที่ Template ID นี้ และเพิ่ม Datastream 
 * สำหรับ V10, V11, V12, V13, V14, V15, V16, V17
 */
#define BLYNK_PRINT Serial
#define BLYNK_TEMPLATE_ID "TMPL6o6yhl5E2"
#define BLYNK_TEMPLATE_NAME "SERVO"
#define BLYNK_AUTH_TOKEN "MktnzUmPaI7GUyUH9GEcirfNF3cNT_Q-"
#include <BlynkSimpleEsp32.h>

char auth[] = BLYNK_AUTH_TOKEN;
char ssid[] = "numtb5332";
char pass[] = "num53322535";

// --- (3) รวม Global Variables (Hardware) ---

// (จาก V2.ino - Servo)
Servo servo1, servo2;

// (จาก V2.ino - LCD)
LiquidCrystal_I2C lcd(0x27, 16, 2);
#define SDA_PIN 21
#define SCL_PIN 22

const int buzzerPin = 19;
const int buzzerFreq = 2500;
const int resolution = 8;
const int VOLUME_OFF = 0;
const int BEEP_VOLUME = 255;
const int BEEP_DURATION = 50;

// (จาก IRSensorBlynkv2.ino - 8 IR Sensors)
const int totalSpots = 8; // (เปลี่ยนจาก 2 เป็น 8)
int irPins[totalSpots] = { 32, 35, 33, 25, 14, 13, 12, 34 };

// --- (4) รวม Global Variables (Logic) ---
int lastStatus[totalSpots]; // (ขนาด 8)
int occupiedSpots = 0;
int availableSpots = 0;
// int lastEntranceStatus = -1; // (ลบออกแล้ว)
BlynkTimer timer;            // (จากทั้ง 2 ไฟล์)


// --- (5) ฟังก์ชัน Servo (จาก V2.ino) ---
BLYNK_WRITE(V0)
{
  int s0 = param.asInt();
  Serial.println("Servo 1 moving (command from web/app).");
  servo1.write(s0);
  Blynk.virtualWrite(V2, s0);
  doBeep();
}

BLYNK_WRITE(V1)
{
  int s1 = param.asInt();
  Serial.println("Servo 2 moving (command from web/app).");
  servo2.write(s1);
  Blynk.virtualWrite(V3, s1);
  doBeep();
}

// --- (6) ฟังก์ชัน LCD (จาก V2.ino) ---
void updateLCD() {
  availableSpots = totalSpots - occupiedSpots; // (ตอนนี้ totalSpots = 8)
  lcd.clear();
  lcd.setCursor(0, 0); 
  lcd.print("Occupied: ");
  lcd.print(occupiedSpots);
  lcd.print(" / ");
  lcd.print(totalSpots); // (จะแสดงเลข 8)
  lcd.setCursor(0, 1);
  lcd.print("Available: ");
  lcd.print(availableSpots);
}

// --- (7) ฟังก์ชัน Buzzer (จาก V2.ino) ---
void stopBeep() {
  ledcWrite(buzzerPin, VOLUME_OFF);
}

void doBeep() {
  Serial.println("Servo moved! (Beep!)");
  ledcWrite(buzzerPin, BEEP_VOLUME);
  timer.setTimeout(BEEP_DURATION, stopBeep);
}

// --- (8) [ฟังก์ชันหลัก] รวม Logic การเช็ค Sensor ---
// (รวม checkParkingSensors และ checkSensors เข้าด้วยกัน)
void checkAllSensors()
{
  bool statusHasChanged = false; // (จาก V2.ino)

  // (วนลูป 8 รอบ)
  for (int i = 0; i < totalSpots; i++) {
    int currentState = 0;
    int sensorState = digitalRead(irPins[i]);

    if (sensorState == LOW) {
      currentState = 1; // 1 = จอด
    }

    //
    // (A) Logic Entrance Sensor (i == 0) ถูกลบออกจากตรงนี้
    //

    //
    // (B) Logic จาก V2.ino (นับที่จอด) และ IRSensorBlynkv2.ino (ส่ง V10-V17)
    //
    if (currentState != lastStatus[i]) {
      
      // (B.1) Logic การนับจำนวน (จาก V2.ino)
      if (currentState == 1) { 
        occupiedSpots++;
        Serial.print("Spot "); Serial.print(i); Serial.println(" -> PARKED");
      } else { 
        occupiedSpots--;
        Serial.print("Spot "); Serial.print(i); Serial.println(" -> EMPTY");
      } 
      statusHasChanged = true;

      // (B.2) Logic การส่งสถานะแยก V10-V17 (จาก IRSensorBlynkv2.ino)
      String spotName = "";
      if (i < 4) {
        spotName = "A" + String(i + 1); // A1-A4
      } else {
        spotName = "B" + String(i - 3); // B1-B4
      }
      int virtualPin = i + 10; // (i=0 -> V10, i=7 -> V17)
      
      Blynk.virtualWrite(virtualPin, currentState);
      Serial.print("Blynk "); Serial.print(spotName); 
      Serial.print(" (V"); Serial.print(virtualPin); 
      Serial.print(") status sent: "); Serial.println(currentState);
      
      // (B.3) อัปเดตสถานะล่าสุด
      lastStatus[i] = currentState;
    } 
  } // สิ้นสุด For Loop

  // (C) อัปเดต LCD ถ้ามีการเปลี่ยนแปลง (จาก V2.ino)
  if (statusHasChanged) {
    Serial.println("Change detected, updating LCD...");
    updateLCD();
  }
} 

//==================================================
// SETUP: (รวมกัน)
//==================================================
void setup()
{
  Serial.begin(115200);
  Serial.println("Combined System Booting...");
  Serial.println("8 IR + 2 Servo + LCD + Buzzer");

  // --- (Setup Servo จาก V2.ino) ---
  servo1.attach(26);
  servo2.attach(27);
  
  // --- (Setup LCD จาก V2.ino) ---
  Wire.begin(SDA_PIN, SCL_PIN);
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Parking System");
  lcd.setCursor(0, 1);
  lcd.print("Scanning 8 spots...");

  // --- (Setup Buzzer จาก V2.ino) ---
  ledcAttach(buzzerPin, buzzerFreq, resolution);
  ledcWrite(buzzerPin, VOLUME_OFF); 
  
  // --- (Setup IR Pins - ใช้ Logic จาก V2.ino) ---
  // (เพราะมีการนับ occupiedSpots เริ่มต้นด้วย)
  for (int i = 0; i < totalSpots; i++) { // (วน 8 รอบ)
    pinMode(irPins[i], INPUT);
    int sensorState = digitalRead(irPins[i]);
    if (sensorState == LOW) {
      lastStatus[i] = 1;
      occupiedSpots++;
    } else {
      lastStatus[i] = 0;
    }
  }
  
  Serial.println("Initial scan complete.");
  updateLCD(); // (แสดงผล LCD ครั้งแรก)

  // --- (Setup Blynk จาก V2.ino) ---
  Blynk.begin(auth , ssid, pass);
  
  // (ตั้ง Timer ให้เรียกฟังก์ชันที่รวมแล้ว)
  timer.setInterval(100L, checkAllSensors);
}

//==================================================
// LOOP: (เหมือนเดิม)
//==================================================
void loop() 
{
  Blynk.run();
  timer.run();
}