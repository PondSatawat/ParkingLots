/*
 * ========================================================
 * ===    โค้ดสำหรับ ESP32 (IR Sensor 2 ช่อง + Firebase)   ===
 * ========================================================
 */

// --- (1) Library (เฉพาะที่จำเป็น) ---
#include <WiFi.h>
#include <FirebaseClient.h>
#include <time.h>

// --- (2) Configs ---
char ssid[] = "Sakchai_2.4G";
char pass[] = "3112311231";

// (Firebase Config - (ดึงมาจาก firebase.js))
#define API_KEY "AIzaSyCgKTtjGEHyoqZ0cDa5QZMwQe8c0iSEo4w"
#define DATABASE_URL "https://loginparklotconsole-default-rtdb.asia-southeast1.firebasedatabase.app"

// --- (3) Global Variables ---
const int totalSpots = 8;
int irPins[totalSpots] = { 32, 35, 33, 25, 14, 13, 12, 34 };
int lastStatus[totalSpots];

// (Firebase Objects)
FirebaseData fbdo;
FirebaseAuth auth_firebase;
FirebaseConfig config_firebase;

// (ตัวแปรสำหรับ Timer (Non-Blocking))
unsigned long previousMillis = 0;
const long interval = 100; // 100ms

// --- (4) ฟังก์ชันเช็คที่จอดรถ ---
void checkParkingSensors()
{ 
  // (Loop นี้จะวน 2 รอบ)
  for (int i = 0; i < totalSpots; i++) {
    int currentState = 0;
    int sensorState = digitalRead(irPins[i]);

    if (sensorState == LOW) {
      currentState = 1; // 1 = จอด
    } 

    // (ตรวจสอบว่าสถานะเปลี่ยนหรือไม่)
    if (currentState != lastStatus[i]) {
      
      String spotName = "A" + String(i + 1); // (i=0 -> "A1", i=1 -> "A2")
      
      // (หัวใจหลัก: ส่งสถานะไป Firebase RTDB)
      if(Firebase.RTDB.setInt(&fbdo, "/parkingStatus/spots/" + spotName, currentState)) {
         Serial.print("RTDB "); Serial.print(spotName); Serial.print(" status sent: ");
         Serial.println(currentState);
      } else {
         Serial.println("RTDB FAILED: " + fbdo.errorReason());
      }
      
      lastStatus[i] = currentState;
    } 
  
  } // (จบ 'for' loop)
} 

//==================================================
// SETUP:
//==================================================
void setup()
{
  Serial.begin(115200);

  // --- (1) Setup Hardware (IR 2 ช่อง) ---
  for (int i = 0; i < totalSpots; i++) {
    pinMode(irPins[i], INPUT);
    
    // (สแกนครั้งแรก)
    int sensorState = digitalRead(irPins[i]);
    if (sensorState == LOW) {
      lastStatus[i] = 1;
    } else {
      lastStatus[i] = 0;
    }
  }

  // --- (2) เชื่อมต่อ WiFi ---
  Serial.print("Connecting to Wi-Fi...");
  WiFi.begin(ssid, pass);
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(500);
  }
  Serial.println(" Connected!");
  
  // (เพิ่ม) โค้ด Sync เวลา (จำเป็นสำหรับ Firebase)
  Serial.print("Waiting for NTP time sync...");
  configTime(3600 * 7, 0, "pool.ntp.org"); 
  time_t now = time(nullptr);
  while (now < 8 * 3600 * 2) { 
    delay(500);
    Serial.print(".");
    now = time(nullptr);
  }
  Serial.println(" Time sync complete!");

  // --- (3) เชื่อมต่อ Firebase ---
  config_firebase.api_key = API_KEY;
  config_firebase.database_url = DATABASE_URL;
  auth_firebase.user.email = "esp32@project.com";
  auth_firebase.user.password = "esp32pass";
  //Firebase.begin(&config_firebase, &auth_firebase);
  //Firebase.reconnectWiFi(true);
  
  Serial.print("Waiting for Firebase to be ready...");
  while (Firebase.ready() == false) {
    Serial.print(".");
    delay(500);
  }
  Serial.println(" Firebase is ready!");

  // (4) ส่งสถานะเริ่มต้นไป RTDB
  Serial.println("Sending initial status to RTDB...");
  for (int i = 0; i < totalSpots; i++) {
    String spotName = "A" + String(i + 1);
    Firebase.RTDB.setInt(&fbdo, "/parkingStatus/spots/" + spotName, lastStatus[i]);
  }
}

//==================================================
// LOOP:
//==================================================
void loop() 
{
  // (ใช้ Timer แบบ Non-Blocking)
  unsigned long currentMillis = millis();
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;
    checkParkingSensors(); // (เรียกฟังก์ชันเช็ก Sensor ทุก 100ms)
  }
}