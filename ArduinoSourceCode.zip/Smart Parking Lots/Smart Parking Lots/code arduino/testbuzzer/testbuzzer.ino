// กำหนดขา GPIO ที่เราเชื่อมต่อ
const int irSensorPin = 18;  // ขา OUT ของ IR Sensor
const int buzzerPin = 19;    // ขา I/O ของ Buzzer
const int buzzerFreq = 2500;
const int resolution = 8;
const int VOLUME_OFF = 0;
const int BEEP_VOLUME = 128; // ความดัง (0-255)
// const int BEEP_DURATION = 50; // ไม่ได้ใช้ในโค้ดนี้

// กำหนดช่องสัญญาณ PWM
const int buzzerChannel = 0;

void setup() {
  Serial.begin(115200);
  pinMode(irSensorPin, INPUT);

  // ⭐️ ตั้งค่า ledc (PWM) สำหรับ Buzzer
  ledcSetup(buzzerChannel, buzzerFreq, resolution);
  ledcAttach(buzzerPin, buzzerChannel);
  
  // ปิดเสียงตอนเริ่มต้น
  ledcWrite(buzzerChannel, VOLUME_OFF);
}

void loop() {
  int sensorState = digitalRead(irSensorPin);

  if (sensorState == LOW) {
    Serial.println("ตรวจพบสิ่งกีดขวาง!");
    // ⭐️ สั่งให้ Buzzer ดัง (ด้วยความดังครึ่งหนึ่ง 128/255)
    ledcWrite(buzzerChannel, BEEP_VOLUME); 
  } 
  else {
    Serial.println("ปกติ");
    // ⭐️ สั่งให้ Buzzer ดับ
    ledcWrite(buzzerChannel, VOLUME_OFF);
  }

  delay(100); 
}