/*
 * ===================================================
 * === โค้ดรวม (Servo + Parking LCD) สำหรับ ESP32 ===
 * ===================================================
 */

/* Comment this out to disable prints and save space */
#define BLYNK_PRINT Serial
#define BLYNK_TEMPLATE_ID "TMPL6o6yhl5E2"
#define BLYNK_TEMPLATE_NAME "SERVO"
#define BLYNK_AUTH_TOKEN "MktnzUmPaI7GUyUH9GEcirfNF3cNT_Q-"

// --- (1) รวม #include จากทั้ง 2 ไฟล์ ---
#include <WiFi.h>
#include <WiFiClient.h>
#include <BlynkSimpleEsp32.h> // (มาจาก servo.ino)
#include <ESP32Servo.h>       // (มาจาก servo.ino)
#include <Wire.h>             // (มาจาก parking.ino) [cite: 13]
#include <LiquidCrystal_I2C.h> // (มาจาก parking.ino) [cite: 13]

// --- (2) รวมตัวแปร Global จากทั้ง 2 ไฟล์ ---

// (จาก servo.ino)
Servo servo1, servo2;
char auth[] = BLYNK_AUTH_TOKEN;
char ssid[] = "numtb5332";
char pass[] = "num53322535";

// (จาก parking.ino)
LiquidCrystal_I2C lcd(0x27, 16, 2);
#define SDA_PIN 21
#define SCL_PIN 22

const int totalSpots = 2;
int irPins[totalSpots] = { 32, 35 };
int lastStatus[totalSpots];
int occupiedSpots = 0;
int availableSpots = 0;

// (เพิ่ม) สร้าง Timer สำหรับ Blynk
BlynkTimer timer;

// --- (3) ฟังก์ชันจาก servo.ino ---
BLYNK_WRITE(V0)
{
  int s0 = param.asInt(); 
  servo1.write(s0);
  Blynk.virtualWrite(V2, s0);
} 

BLYNK_WRITE(V1)
{
  int s1 = param.asInt();
  servo2.write(s1);
  Blynk.virtualWrite(V3, s1);
} 

// --- (4) ฟังก์ชันจาก parking.ino ---
void updateLCD() {
  availableSpots = totalSpots - occupiedSpots;
  lcd.clear();
  lcd.setCursor(0, 0); 
  lcd.print("Occupied: ");
  lcd.print(occupiedSpots);
  lcd.print(" / ");
  lcd.print(totalSpots);
  lcd.setCursor(0, 1);
  lcd.print("Available: ");
  lcd.print(availableSpots);
}

// --- (5) [ใหม่] ย้ายโค้ดใน loop() ของ parking.ino มาไว้ในฟังก์ชันนี้ ---
void checkParkingSensors()
{
  bool statusHasChanged = false;

  for (int i = 0; i < totalSpots; i++) {
    int currentState = 0;
    int sensorState = digitalRead(irPins[i]);

    if (sensorState == LOW) {
      currentState = 1;
    }

    if (currentState != lastStatus[i]) {
      if (currentState == 1) {
        occupiedSpots++;
        Serial.print("Spot "); Serial.print(i); Serial.println(" -> PARKED");
      } else {
        occupiedSpots--;
        Serial.print("Spot "); Serial.print(i); Serial.println(" -> EMPTY");
      }
      lastStatus[i] = currentState;
      statusHasChanged = true;
    }
  } // สิ้นสุด For Loop

  if (statusHasChanged) {
    Serial.println("Change detected, updating LCD...");
    updateLCD();
    
    // (เพิ่ม) ส่งข้อมูลที่อัปเดตไป Blynk (ถ้าต้องการ)
    //Blynk.virtualWrite(V_PIN_OCCUPIED, occupiedSpots);
    //Blynk.virtualWrite(V_PIN_AVAILABLE, availableSpots);
  }
}

//==================================================
// SETUP: (รวมกัน)
//==================================================
void setup()
{
  Serial.begin(115200); // (ใช้ 115200 ดีกว่า 9600)

  // --- (Setup Servo) ---
  servo1.attach(26);
  servo2.attach(27);

  // --- (Setup LCD) ---
  Wire.begin(SDA_PIN, SCL_PIN);
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Parking System");
  lcd.setCursor(0, 1);
  lcd.print("Scanning...");

  
  for (int i = 0; i < totalSpots; i++) {
    pinMode(irPins[i], INPUT);
    int sensorState = digitalRead(irPins[i]);
    if (sensorState == LOW) {
      lastStatus[i] = 1;
      occupiedSpots++;
    } else {
      lastStatus[i] = 0;
    }
  }
  
  Serial.println("Initial scan complete.");
  updateLCD();

  // --- (Setup Blynk) ---
  Blynk.begin(auth , ssid, pass);
  
  timer.setInterval(100L, checkParkingSensors);
}

void loop() 
{
  Blynk.run();
  timer.run();
}