// --- โค้ดสำหรับ "Passive Buzzer" (ดัง "ติ๊ด" เดียวสั้นๆ) ---
// --- อัปเดตสำหรับ ESP32 Core v3.x ---

#include <Arduino.h>

const int irSensorPin = 18;
const int buzzerPin = 19;

// --- ตั้งค่า LEDC ---
const int buzzerFreq = 2500; // ความถี่เสียง (ทุ้ม/แหลม)
const int resolution = 8;    // 8-bit (0-255)

// --- ตั้งค่าเสียง "ติ๊ด" ---
const int VOLUME_OFF = 0;
const int BEEP_VOLUME = 128;   // ความดังตอน "ติ๊ด" (128 = ดังสุด)
const int BEEP_DURATION = 50;  // <--- ความยาวของเสียง "ติ๊ด" (50 = 0.05 วินาที)

// --- ตัวแปรสำหรับจำสถานะ ---
int lastSensorState = HIGH; // เริ่มต้นโดยสมมติว่า "ไม่พบวัตถุ" (HIGH)

void setup() {
  Serial.begin(115200);
  pinMode(irSensorPin, INPUT);

  // ตั้งค่า LEDC
  ledcAttach(buzzerPin, buzzerFreq, resolution);
  
  // ปิดเสียงตอนเริ่ม
  ledcWrite(buzzerPin, VOLUME_OFF); 

  // อ่านค่าเริ่มต้นของ sensor เก็บไว้
  lastSensorState = digitalRead(irSensorPin);
}

void loop() {
  // อ่านค่าสถานะปัจจุบัน
  int currentSensorState = digitalRead(irSensorPin);

  // --- ตรวจสอบการเปลี่ยนแปลง ---
  // เช็กว่า "เพิ่งจะ" ตรวจพบวัตถุหรือไม่?
  // (เงื่อนไข: สถานะก่อนหน้า = HIGH และ สถานะปัจจุบัน = LOW)
  if (lastSensorState == HIGH && currentSensorState == LOW) {
    
    Serial.println("พบวัตถุ! (ติ๊ด!)"); // ส่งเสียง "ติ๊ด" หนึ่งครั้ง
    
    ledcWrite(buzzerPin, BEEP_VOLUME); // 1. เปิดเสียง
    delay(BEEP_DURATION);              // 2. หน่วงเวลาสั้นๆ (นี่คือความยาวเสียง)
    ledcWrite(buzzerPin, VOLUME_OFF);  // 3. ปิดเสียงทันที
  }

  // อัปเดตสถานะล่าสุด เพื่อใช้ในการเช็กรอบถัดไป
  lastSensorState = currentSensorState;

  // หน่วงเวลาเล็กน้อยเพื่อลดการสั่นของสัญญาณ (debounce)
  delay(10); 
}