/*
 * ========================================================
 * ===    โค้ดทดสอบ (Minimal): 1 IR Sensor + Blynk       ===
 * ========================================================
 */

// --- (1) Library Blynk ---
#include <WiFi.h>
#include <WiFiClient.h>

// (Define ของ Blynk ต้องอยู่ก่อน Include)
#define BLYNK_PRINT Serial
#define BLYNK_TEMPLATE_ID "TMPL6a2aFZZpS"
#define BLYNK_TEMPLATE_NAME "IR Sensor"
#define BLYNK_AUTH_TOKEN "miARri2uzrxTCLRrfPHQILVKJtxBCeiO"
#include <BlynkSimpleEsp32.h> 

// --- (2) Configs Wi-Fi ---
char ssid[] = "numtb5332";
char pass[] = "num53322535";
char auth[] = BLYNK_AUTH_TOKEN;

const int totalSpots = 8;
int irPins[totalSpots] = { 32, 35, 33, 25, 14, 13, 12, 34 };
int lastStatus[totalSpots];

BlynkTimer timer;

// --- (4) (แก้ไข) ฟังก์ชันสำหรับเช็ค Sensor (วนลูป 8 รอบ) ---
void checkSensors()
{ 
  for (int i = 0; i < totalSpots; i++) {
    int currentState = 0; // (0 = ว่าง)
    int sensorState = digitalRead(irPins[i]);

    if (sensorState == LOW) {
      currentState = 1; // 1 = จอด
    } 

    // (ตรวจสอบว่าสถานะเปลี่ยนหรือไม่)
    if (currentState != lastStatus[i]) {
      
      //
      // 👇 (นี่คือ Logic ที่คุณต้องการ) 👇
      //
      String spotName = "";
      if (i < 4) {
        // (i = 0 ถึง 3) -> แถว A
        spotName = "A" + String(i + 1); // A1, A2, A3, A4
      } else {
        // (i = 4 ถึง 7) -> แถว B
        spotName = "B" + String(i - 3); // B1, B2, B3, B4
      }

      // (คำนวณ) Virtual Pin ที่จะส่ง (V10 - V17)
      int virtualPin = i + 10; // (i=0 -> V10, i=7 -> V17)
      
      // (ส่งสถานะไป Blynk)
      Blynk.virtualWrite(virtualPin, currentState);
      
      Serial.print("Blynk "); Serial.print(spotName); 
      Serial.print(" (V"); Serial.print(virtualPin); 
      Serial.print(") status sent: "); Serial.println(currentState);
      //
      // 👆 (สิ้นสุด Logic) 👆
      //
      
      lastStatus[i] = currentState;
    } 
  }
} 

//==================================================
// SETUP: (อัปเกรด)
//==================================================
void setup()
{
  Serial.begin(115200);
  Serial.println("Blynk + 8 IR Sensors Test...");

  // (Setup IR Pins - วนลูป 8 รอบ)
  for (int i = 0; i < totalSpots; i++) {
    pinMode(irPins[i], INPUT);
    // (สแกนครั้งแรก)
    int sensorState = digitalRead(irPins[i]);
    if (sensorState == LOW) {
      lastStatus[i] = 1;
    } else {
      lastStatus[i] = 0;
    }
  }

  // (เชื่อมต่อ Blynk)
  Blynk.begin(auth , ssid, pass);
  
  // (ตั้ง Timer ให้เช็ก Sensor ทุก 100ms)
  timer.setInterval(100L, checkSensors);
}

//==================================================
// LOOP: (เหมือนเดิม)
//==================================================
void loop() 
{
  Blynk.run();
  timer.run();
}