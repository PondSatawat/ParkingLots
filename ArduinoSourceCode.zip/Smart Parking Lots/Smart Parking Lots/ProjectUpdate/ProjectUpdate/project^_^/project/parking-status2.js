import { auth, db, rtdb } from './firebase.js';
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.4.0/firebase-auth.js";
import { collection, addDoc, query, where, getDocs, updateDoc, doc, Timestamp } from "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js";
import { ref, set, onValue } from "https://www.gstatic.com/firebasejs/12.4.0/firebase-database.js"; // 👈 (ต้องมี onValue)

//
// (ลบ) ฟังก์ชัน Blynk API ทิ้ง
//

// --- อ้างอิง UI Elements (เหมือนเดิม) ---
const loadingStatus = document.getElementById("loading-status");
// ... (UI Elements ทั้งหมด) ...
const cancelPaymentBtn = document.getElementById("cancelPaymentBtn");

// --- ตัวแปรเก็บสถานะ ---
let currentUser = null;
let currentParkingDocId = null;
let currentParkingData = null;
let parkingTimerInterval = null;
let calculatedCost = 0;
let irEntranceStatus = 0; // 👈 (ตัวแปรจำสถานะ IR)

// --- (แก้ไข) onAuthStateChanged (เพิ่ม Listener) ---
onAuthStateChanged(auth, (user) => {
  if (user) {
    currentUser = user;
    checkUserParkingStatus(user.uid);
    startEntranceListener(); // 👈 (เพิ่ม) เริ่ม "ฟัง" สถานะ IR
  } else {
    window.location.href = "index.html";
  }
});

//
// 🚀 (เพิ่ม) ฟังก์ชัน "ฟัง" สถานะ IR จาก RTDB
//
function startEntranceListener() {
  const irRef = ref(rtdb, 'parkingStatus/spots/A1'); // 👈 (ฟัง A1 ซึ่งคือ irPins[0])
  
  onValue(irRef, (snapshot) => {
    const status = snapshot.val();
    console.log("RTDB Entrance status changed:", status);
    
    if (status === 1) {
      irEntranceStatus = 1;
      checkInBtn.disabled = false;
      checkinMessage.textContent = "ตรวจพบรถ! (พร้อมเข้าจอด)";
    } else {
      irEntranceStatus = 0;
      checkInBtn.disabled = true;
      checkinMessage.textContent = "กรุณาขับรถให้ตรงเซ็นเซอร์";
    }
  });
}

// --- 3. เช็กสถานะการจอด (เหมือนเดิม) ---
async function checkUserParkingStatus(uid) {
  // ... (โค้ดเหมือนเดิม) ...
}

// --- 4. แสดงผล UI (แก้ไข) ---
function showNotParkedState() {
  // ... (โค้ดเหมือนเดิม) ...
  
  // (เพิ่ม) ตั้งค่าปุ่ม "เข้า" เริ่มต้น
  checkInBtn.disabled = true;
  checkinMessage.textContent = "กรุณาขับรถให้ตรงเซ็นเซอร์";
  checkoutMessage.textContent = "";   
  priceDisplay.style.display = "none"; 
}
function showParkedState(data) {
  // ... (โค้ดเหมือนเดิม) ...
}

// --- 5. (แก้ไข) จัดการการ "เข้าจอด" (Logic ใหม่) ---
checkInBtn.addEventListener("click", async () => {
  const plate = licenseInput.value.trim();
  if (!plate) {
    alert("กรุณากรอกป้ายทะเบียน");
    return;
  }
  if (!currentUser) return;

  // (A) [ใหม่] เช็กสถานะที่ "จำ" ไว้
  if (irEntranceStatus !== 1) {
    alert("ไม่เจอรถ! (กรุณาขับรถให้ตรงเซ็นเซอร์)");
    return; // (ไม่ทำงานต่อ)
  }

  checkInBtn.disabled = true;
  checkinMessage.textContent = "กำลังบันทึกและเปิดประตู...";

  try {
    // (B) บันทึก Log ลง Firestore (เหมือนเดิม)
    await addDoc(collection(db, "ParkingLogs"), {
      // ... (ข้อมูล Log เหมือนเดิม) ...
    });

    // (C) [แก้ไข] สั่งเปิดประตู (เขียนไปที่ RTDB)
    await set(ref(rtdb, 'gateCommands/entrance'), 1); // 1 = OPEN

    checkinMessage.textContent = "บันทึกสำเร็จ ประตูทางเข้าเปิดแล้ว!";
    
    // (หน่วงเวลา 2 วิ แล้วสั่งปิด)
    setTimeout(async () => {
      await set(ref(rtdb, 'gateCommands/entrance'), 0); // 0 = CLOSE
    }, 2000);

    // ... (โค้ด setTimeout รีเฟรชหน้า เหมือนเดิม) ...

  } catch (error) {
    // ... (โค้ด catch error เหมือนเดิม) ...
  }
});


// --- 6. ปุ่ม "ออก" - (เปิด Modal) (เหมือนเดิม) ---
checkOutBtn.addEventListener("click", async () => {
  // ... (โค้ดนี้เหมือนเดิมทั้งหมด) ...
});


// --- 7. (แก้ไข) ปุ่ม "โอนเงินเรียบร้อย" (ใน Modal) ---
confirmPaymentBtn.addEventListener("click", async () => {
  // ... (โค้ด (A) อัปเดต Log Firestore เหมือนเดิม) ...
  
  // (B) [แก้ไข] สั่งเปิดประตูทางออก (เขียนไปที่ RTDB)
  await set(ref(rtdb, 'gateCommands/exit'), 1); // 1 = OPEN

  // ... (โค้ด (C) แสดงข้อความ เหมือนเดิม) ...
  
  // (หน่วงเวลา 2 วิ แล้วสั่งปิด)
  setTimeout(async () => {
      await set(ref(rtdb, 'gateCommands/exit'), 0); // 0 = CLOSE
  }, 2000);

  // ... (โค้ด (D) หยุด Timer และ setTimeout รีเฟรชหน้า เหมือนเดิม) ...
});


// --- 8. ปุ่ม "ยกเลิก" (ใน Modal) (เหมือนเดิม) ---
cancelPaymentBtn.addEventListener("click", () => {
  // ... (โค้ดนี้เหมือนเดิม) ...
});