//
// 🚀 (ไฟล์แก้ไข) dashboard-data.js (เพิ่ม Firestore Query)
//

// (เพิ่ม) 1. Import 'db' (Firestore) และฟังก์ชันที่จำเป็น
import { db } from './firebase.js';
import { collection, query, where, getDocs } from "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js";

// (Token Blynk - เหมือนเดิม)
const BLYNK_AUTH_TOKEN = "miARri2uzrxTCLRrfPHQILVKJtxBCeiO";
const BLYNK_SERVER_URL = "https://blynk.cloud/external/api";

// (ฟังก์ชัน "อ่าน" (Read) จาก Blynk - เหมือนเดิม)
async function getBlynkValue(virtualPin) {
  const url = `${BLYNK_SERVER_URL}/get?token=${BLYNK_AUTH_TOKEN}&${virtualPin}`;
  try {
    const response = await fetch(url);
    if (response.ok) {
      const data = await response.json();
      return parseInt(data); 
    } else {
      console.error(`Blynk API error (GET ${virtualPin}): ${response.statusText}`);
      return -1;
    }
  } catch (error) {
    console.error(`Blynk network error (GET ${virtualPin}):`, error);
    return -1; 
  }
}

// 1. อ้างอิง ID (เหมือนเดิม)
const totalSpotsEl = document.getElementById("total-spots-p");
const availableSpotsEl = document.getElementById("available-spots-p");
const occupiedSpotsEl = document.getElementById("occupied-spots-p");
// (เพิ่ม) 2. อ้างอิง ID ใหม่
const usersTodayEl = document.getElementById("users-today-p");

// 3. (แก้ไข) Pin ที่จะตรวจสอบ (8 ช่อง - เหมือนเดิม)
const PINS_TO_CHECK = [
  "v10", "v11", "v12", "v13", // A1-A4
  "v14", "v15", "v16", "v17"  // B1-B4
];
const totalSpots = PINS_TO_CHECK.length; 

// 4. ฟังก์ชัน (Blynk) (เหมือนเดิม)
async function updateDashboardData() {
  if (!availableSpotsEl) return; 

  const promises = PINS_TO_CHECK.map(pin => getBlynkValue(pin));
  const statuses = await Promise.all(promises);

  let occupiedCount = 0;
  statuses.forEach(status => {
    if (status === 1) { 
      occupiedCount++;
    }
  });
  let availableCount = totalSpots - occupiedCount;

  totalSpotsEl.textContent = totalSpots + " ช่อง";
  availableSpotsEl.textContent = availableCount + " ช่อง";
  occupiedSpotsEl.textContent = occupiedCount + " ช่อง";
}

//
// 🚀 (เพิ่ม) 5. ฟังก์ชันใหม่ (สำหรับ Firestore)
//
async function updateUsageStats() {
  if (!usersTodayEl) return; // (ถ้าไม่เจอ = ไม่ได้อยู่หน้า Dashboard)

  try {
    // (สร้าง) วันที่ปัจจุบัน "YYYY-MM-DD"
    const todayString = new Date().toISOString().split('T')[0];
    
    // (Query) ค้นหาใน 'ParkingLogs' ที่ "CheckInDate" == "วันนี้"
    const logRef = collection(db, "ParkingLogs");
    const q = query(logRef, where("CheckInDate", "==", todayString));
    
    const querySnapshot = await getDocs(q);

    // (นับ) จำนวนเอกสารที่เจอ
    const usersTodayCount = querySnapshot.size;

    // (อัปเดต) Card
    usersTodayEl.textContent = usersTodayCount + " คน";

  } catch (error) {
    console.error("Error fetching usage stats:", error);
    usersTodayEl.textContent = "Error";
  }
}

// 6. (แก้ไข) เริ่มการทำงาน
document.addEventListener("DOMContentLoaded", () => {
  // (Blynk)
  updateDashboardData(); 
  setInterval(updateDashboardData, 100); // (Blynk โหลดทุก 5 วิ)

  // (Firestore)
  updateUsageStats();
  setInterval(updateUsageStats, 2000); // (Firestore โหลดทุก 1 นาที (ประหยัด))
});