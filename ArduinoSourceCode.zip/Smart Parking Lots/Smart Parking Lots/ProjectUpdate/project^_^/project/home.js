import { auth, db, rtdb } from './firebase.js'; 
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.4.0/firebase-auth.js";
import { collection, addDoc, query, where, getDocs, updateDoc, doc, Timestamp } from "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js";
import { ref, set } from "https://www.gstatic.com/firebasejs/12.4.0/firebase-database.js";

// --- อ้างอิง UI Elements ---
const loadingStatus = document.getElementById("loading-status");
const notParkedState = document.getElementById("not-parked-state");
const parkedState = document.getElementById("parked-state");

const licenseInput = document.getElementById("licenseInput");
const checkInBtn = document.getElementById("checkInBtn");
const checkinMessage = document.getElementById("checkin-message");

const parkedLicense = document.getElementById("parked-license");
const parkedTime = document.getElementById("parked-time");
const checkOutBtn = document.getElementById("checkOutBtn");
const checkoutMessage = document.getElementById("checkout-message");
const priceDisplay = document.getElementById("price-display");
const finalPrice = document.getElementById("final-price");

// (เพิ่ม) อ้างอิง UI ของ Modal
const paymentModal = document.getElementById("payment-modal");
const modalPrice = document.getElementById("modal-price");
const confirmPaymentBtn = document.getElementById("confirmPaymentBtn");
const cancelPaymentBtn = document.getElementById("cancelPaymentBtn");

// --- ตัวแปรเก็บสถานะ ---
let currentUser = null;
let currentParkingDocId = null; 
let currentParkingData = null; 
let parkingTimerInterval = null;
let calculatedCost = 0;

// --- 2. ตรวจสอบการล็อกอิน ---
onAuthStateChanged(auth, (user) => {
  if (user) {
    currentUser = user;
    checkUserParkingStatus(user.uid);
  } else {
    window.location.href = "index.html"; 
  }
});

// --- 3. เช็กสถานะการจอด ---
async function checkUserParkingStatus(uid) {
  try {
    const logRef = collection(db, "ParkingLogs");
    const q = query(logRef, 
      where("UserID", "==", uid), 
      where("Status", "==", "จอดอยู่")
    );
    const querySnapshot = await getDocs(q);
    
    if (querySnapshot.empty) {
      showNotParkedState();
    } else {
      const doc = querySnapshot.docs[0];
      currentParkingDocId = doc.id;
      currentParkingData = doc.data();
      showParkedState(currentParkingData);
    }
  } catch (error) {
    console.error("Error checking status:", error);
    loadingStatus.textContent = "Error checking status.";
  }
}

// --- 4. แสดงผล UI (แยกตามสถานะ) ---
function showNotParkedState() {
  if (parkingTimerInterval) {
    clearInterval(parkingTimerInterval);
  }
  loadingStatus.style.display = "none";
  parkedState.style.display = "none";
  notParkedState.style.display = "block";
  checkinMessage.textContent = "";    
  checkoutMessage.textContent = "";   
  priceDisplay.style.display = "none"; 
}

function showParkedState(data) {
  if (parkingTimerInterval) { 
    clearInterval(parkingTimerInterval);
  }

  loadingStatus.style.display = "none";
  notParkedState.style.display = "none";
  parkedState.style.display = "block";

  parkedLicense.textContent = data.LicensePlate;
  const checkInTime = data.CheckInTime.toDate(); 

  function updateTimer() {
    const now = new Date();
    const diffMs = now - checkInTime; 
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);
    const formattedHours = String(hours).padStart(2, '0');
    const formattedMinutes = String(minutes).padStart(2, '0');
    const formattedSeconds = String(seconds).padStart(2, '0');
    parkedTime.textContent = `จอดมา ${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
  }

  updateTimer(); 
  parkingTimerInterval = setInterval(updateTimer, 1000); 

  checkinMessage.textContent = "";    
  checkoutMessage.textContent = "";   
  priceDisplay.style.display = "none"; 
}

// --- 5. จัดการการ "เข้าจอด" (กดปุ่ม Check-in) ---
checkInBtn.addEventListener("click", async () => {
  const plate = licenseInput.value.trim();
  if (!plate) {
    alert("กรุณากรอกป้ายทะเบียน");
    return;
  }
  if (!currentUser) return; 

  checkInBtn.disabled = true;
  checkinMessage.textContent = "กำลังบันทึกข้อมูลและสั่งเปิดประตู...";

  try {
    //
    // ✅ (นี่คือส่วนที่เก็บข้อมูล "เข้า") ✅
    //
    await addDoc(collection(db, "ParkingLogs"), {
      UserID: currentUser.uid,
      UserEmail: currentUser.email, // (เพิ่ม) เก็บ Email ไปด้วยเลย
      LicensePlate: plate,
      CheckInTime: Timestamp.now(), // 👈 เก็บเวลาเข้า
      CheckOutTime: null,
      Status: "จอดอยู่",
      Cost: 0
    });

    // (B) สั่งเปิดประตู (Realtime Database)
    await set(ref(rtdb, 'gateCommands/entrance'), "OPEN");

    checkinMessage.textContent = "บันทึกสำเร็จ ประตูทางเข้าเปิดแล้ว!";
    
    if (parkingTimerInterval) {
      clearInterval(parkingTimerInterval);
    }
    setTimeout(() => {
        checkInBtn.disabled = false;
        checkUserParkingStatus(currentUser.uid);
    }, 2000);

  } catch (error) {
    console.error("Error checking in:", error);
    checkinMessage.textContent = "เกิดข้อผิดพลาด: " + error.message;
    checkInBtn.disabled = false;
  }
});


// --- 6. ปุ่ม "ออก" - (เปิด Modal) ---
checkOutBtn.addEventListener("click", async () => {
  if (!currentParkingData) return;
  
  checkoutMessage.textContent = "กำลังคำนวณค่าจอด...";

  const checkInTime = currentParkingData.CheckInTime.toDate();
  const checkOutTime = new Date(); 
  const diffMs = checkOutTime - checkInTime;
  const diffHours = Math.ceil(diffMs / (1000 * 60 * 60)); 
  const ratePerHour = 10;
  calculatedCost = diffHours * ratePerHour; 

  modalPrice.textContent = calculatedCost; 
  paymentModal.style.display = "flex";
  checkoutMessage.textContent = "";
  priceDisplay.style.display = "none";
});


// --- 7. ปุ่ม "โอนเงินเรียบร้อย" (ใน Modal) ---
confirmPaymentBtn.addEventListener("click", async () => {
  if (!currentUser || !currentParkingDocId || !currentParkingData) return;

  confirmPaymentBtn.disabled = true;
  confirmPaymentBtn.textContent = "กำลังตรวจสอบ...";

  try {
    const checkOutTime = new Date(); 

    //
    // ✅ (นี่คือส่วนที่เก็บข้อมูล "ออก") ✅
    //
    const docRef = doc(db, "ParkingLogs", currentParkingDocId);
    await updateDoc(docRef, {
      CheckOutTime: Timestamp.fromDate(checkOutTime), // 👈 เก็บเวลาออก
      Status: "ออกแล้ว",
      Cost: calculatedCost 
    });

    // (B) สั่งเปิดประตูทางออก (Realtime Database)
    await set(ref(rtdb, 'gateCommands/exit'), "OPEN");

    // (C) แสดงข้อความสุดท้าย และปิด Modal
    checkoutMessage.textContent = `ชำระ ${calculatedCost} บาทเรียบร้อย ประตูเปิดแล้ว!`;
    paymentModal.style.display = "none"; 

    // (D) หยุด Timer และรีเฟรชหน้า
    if (parkingTimerInterval) {
      clearInterval(parkingTimerInterval);
    }
    
    setTimeout(() => {
      confirmPaymentBtn.disabled = false;
      confirmPaymentBtn.textContent = "✅ โอนเงินเรียบร้อย (กดยืนยันเพื่อเปิดประตู)";
      checkUserParkingStatus(currentUser.uid); 
    }, 3000); 

  } catch (error) {
    console.error("Error confirming payment:", error);
    alert("เกิดข้อผิดพลาด: " + error.message);
    confirmPaymentBtn.disabled = false;
    confirmPaymentBtn.textContent = "✅ โอนเงินเรียบร้อย (กดยืนยันเพื่อเปิดประตู)";
  }
});


// --- 8. ปุ่ม "ยกเลิก" (ใน Modal) ---
cancelPaymentBtn.addEventListener("click", () => {
  paymentModal.style.display = "none";
});

// (โค้ด logoutBtn ที่หลุดออกมา ถูกลบออกจากจุดนี้แล้ว)