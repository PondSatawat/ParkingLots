import { auth } from "./firebase.js";
import { signInWithEmailAndPassword, sendPasswordResetEmail } from "https://www.gstatic.com/firebasejs/12.4.0/firebase-auth.js";

const loginBtn = document.getElementById("loginBtn");
const forgotPass = document.getElementById("forgotPass");
const message = document.getElementById("message");

loginBtn.addEventListener("click", async () => {
  const email = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  try {
    await signInWithEmailAndPassword(auth, email, password);
    message.style.color = "green";
    message.textContent = "Login successful!";
    setTimeout(() => {
      window.location.href = "home.html";
    }, 1000);
  } catch (err) {
    message.textContent = "Error: " + err.message;
  }
});

forgotPass.addEventListener("click", async () => {
  const email = prompt("Enter your email to reset password:");
  if (email) {
    try {
      await sendPasswordResetEmail(auth, email);
      alert("Password reset link sent to your email.");
    } catch (err) {
      alert("Error: " + err.message);
    }
  }
});

/*
import {auth,db} from "./firebase.js";
import {signInWithEmailAndPassword} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-auth.js";
import {doc,getDoc} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js";

window.addEventListener("DOMContentLoaded", () => {
  const loginBtn = document.getElementById("loginBtn");

  if (loginBtn) {
    loginBtn.addEventListener("click", async () => {
      const email = document.getElementById("email").value;
      const password = document.getElementById("password").value;

      try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        const uid = userCredential.user.uid;

        const userDoc = await getDoc(doc(db, "users", uid));
        if (!userDoc.exists()) {
          alert("ไม่พบข้อมูลผู้ใช้ในระบบ");
          return;
        }

        // เก็บ UID ไว้ใช้ตอนเปิด dashboard
        localStorage.setItem("uid", uid);
        alert("Login สำเร็จ!");
        window.location.href = "dashboard.html";
      } catch (error) {
        alert("Incorrect email or password!");
      }
    });
  }
});
*/